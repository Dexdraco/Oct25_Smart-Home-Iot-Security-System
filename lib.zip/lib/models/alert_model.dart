import 'package:cloud_firestore/cloud_firestore.dart';

class AlertModel {
  final String id;
  final String device;
  final String location;
  final bool motion;
  final Timestamp timestamp;

  AlertModel({
    required this.id,
    required this.device,
    required this.location,
    required this.motion,
    required this.timestamp,
  });

  factory AlertModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return AlertModel(
      id: doc.id,
      device: data['device'] ?? '',
      location: data['location'] ?? '',
      motion: data['motion'] ?? false,
      timestamp: data['timestamp'] ?? Timestamp.now(),
    );
  }
}
