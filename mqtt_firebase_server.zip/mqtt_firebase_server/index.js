const admin = require("firebase-admin");
const mqtt = require("mqtt");
const serviceAccount = require("./serviceAccountKey.json");

// -------------------- Firebase Admin Init --------------------
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount)
});

const firestore = admin.firestore();

// -------------------- MQTT Setup --------------------
const MQTT_BROKER = "mqtt://test.mosquitto.org";
const MQTT_TOPIC = "danish_iot/motion/status";

const client = mqtt.connect(MQTT_BROKER);

client.on("connect", () => {
  console.log("✅ MQTT Connected");
  client.subscribe(MQTT_TOPIC, (err) => {
    if (err) {
      console.error("❌ Failed to subscribe:", err);
    } else {
      console.log("📡 Subscribed to topic:", MQTT_TOPIC);
    }
  });
});

// -------------------- Handle Incoming MQTT Messages --------------------
client.on("message", async (topic, message) => {
  try {
    if (topic === MQTT_TOPIC) {
      const data = JSON.parse(message.toString());

      // Validate expected fields
      if (!data.device || !data.location || data.motion === undefined) {
        console.error("❌ Invalid payload received:", data);
        return;
      }

      // Save to Firestore
      await firestore.collection("alerts").add({
        device: data.device,
        location: data.location,
        motion: data.motion,
        timestamp: admin.firestore.Timestamp.now()
      });

      console.log("🔥 Saved to Firestore:", data);
    }
  } catch (error) {
    console.error("❌ Error processing message:", error);
  }
});

// -------------------- MQTT Error Handling --------------------
client.on("error", (err) => {
  console.error("❌ MQTT Error:", err);
});
